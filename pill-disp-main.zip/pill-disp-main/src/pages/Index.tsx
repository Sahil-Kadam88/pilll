import { useState } from "react";
import { DashboardHeader } from "@/components/DashboardHeader";
import { Navigation } from "@/components/Navigation";
import { ScheduleTab } from "@/components/ScheduleTab";
import { LogsTab } from "@/components/LogsTab";
import { AnalyticsTab } from "@/components/AnalyticsTab";

const Index = () => {
  const [activeTab, setActiveTab] = useState("schedule");

  const renderActiveTab = () => {
    switch (activeTab) {
      case "schedule":
        return <ScheduleTab />;
      case "logs":
        return <LogsTab />;
      case "analytics":
        return <AnalyticsTab />;
      default:
        return <ScheduleTab />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      <main className="container mx-auto px-4 py-4 md:py-8">
        {renderActiveTab()}
      </main>
    </div>
  );
};

export default Index;
