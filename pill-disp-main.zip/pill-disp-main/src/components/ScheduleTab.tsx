import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, Save, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Google Sheets CSV endpoint for schedule
const SCHEDULE_CSV_URL = "https://docs.google.com/spreadsheets/d/1IoftFv4saUdfgdEVED5k4kKNPbdn6o58TNl6Q3Ln6lE/export?format=csv";
// Google Apps Script web app URL for writing
const SCHEDULE_WRITE_URL = "https://script.google.com/macros/s/AKfycbwwPTHFyWMIvVduRJVjUapOC9tnlO7h4VITLaFZ3V_DH6dHQTRvbrrwjdqmCrnI-O0E/exec";

export const ScheduleTab = () => {
  const [morningTime, setMorningTime] = useState("08:00");
  const [eveningTime, setEveningTime] = useState("20:00");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  // Load current schedule on component mount
  useEffect(() => {
    loadCurrentSchedule();
  }, []);

  // Convert 12-hour format (08:28 AM) to 24-hour format (08:28)
  const convertTo24Hour = (time12h: string) => {
    if (!time12h || !time12h.includes(':')) return time12h;
    
    const [time, period] = time12h.split(/\s+/);
    const [hours, minutes] = time.split(':');
    let hour = parseInt(hours);
    
    if (period?.toUpperCase() === 'PM' && hour !== 12) {
      hour += 12;
    } else if (period?.toUpperCase() === 'AM' && hour === 12) {
      hour = 0;
    }
    
    return `${hour.toString().padStart(2, '0')}:${minutes}`;
  };

  // Convert 24-hour format (08:28) to 12-hour format (08:28 AM)
  const convertTo12Hour = (time24h: string) => {
    if (!time24h || !time24h.includes(':')) return time24h;
    
    const [hours, minutes] = time24h.split(':');
    const hour = parseInt(hours);
    const period = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
    
    return `${displayHour.toString().padStart(2, '0')}:${minutes} ${period}`;
  };

  const parseScheduleCSV = (csvText: string) => {
    const lines = csvText.trim().split('\n');
    if (lines.length < 2) return null;
    
    const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
    const values = lines[1].split(',').map(v => v.trim());
    
    const morningIndex = headers.findIndex(h => h.includes('morning'));
    const eveningIndex = headers.findIndex(h => h.includes('evening'));
    
    return {
      morning: morningIndex !== -1 ? convertTo24Hour(values[morningIndex]) : null,
      evening: eveningIndex !== -1 ? convertTo24Hour(values[eveningIndex]) : null
    };
  };

  const loadCurrentSchedule = async () => {
    setLoading(true);
    try {
      const response = await fetch(SCHEDULE_CSV_URL);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const csvText = await response.text();
      const scheduleData = parseScheduleCSV(csvText);
      
      if (scheduleData?.morning) setMorningTime(scheduleData.morning);
      if (scheduleData?.evening) setEveningTime(scheduleData.evening);
      
    } catch (error) {
      console.error("Failed to load schedule:", error);
      toast({
        title: "Connection Error",
        description: "Failed to load current schedule from Google Sheets. Using default times.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const saveSchedule = async () => {
    setSaving(true);
    try {
      // Convert times to 12-hour format for Google Sheets
      const morningFormatted = convertTo12Hour(morningTime);
      const eveningFormatted = convertTo12Hour(eveningTime);
      
      console.log("Saving schedule:", { morningFormatted, eveningFormatted });
      
      // Create form data for Google Apps Script (works better than JSON)
      const formData = new FormData();
      formData.append('morningDose', morningFormatted);
      formData.append('eveningDose', eveningFormatted);
      
      // Send data to Google Apps Script with proper CORS handling
      const response = await fetch(SCHEDULE_WRITE_URL, {
        method: 'POST',
        mode: 'cors',
        body: formData
      });

      console.log("Response status:", response.status);
      console.log("Response headers:", response.headers);
      
      const result = await response.text();
      console.log("Response body:", result);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status} - ${result}`);
      }

      toast({
        title: "Schedule Updated",
        description: `Morning: ${morningFormatted}, Evening: ${eveningFormatted}`,
        className: "border-success bg-success/10",
      });
      
    } catch (error) {
      console.error("Failed to save schedule:", error);
      toast({
        title: "Save Failed", 
        description: `Failed to update schedule: ${error.message}`,
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Loader2 className="h-6 w-6 animate-spin" />
          Loading schedule...
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 fade-in">
      <Card className="gradient-card border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            Pill Schedule
          </CardTitle>
          <CardDescription>
            Set your daily medication times. Changes will sync to your smart dispenser.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="morning-time" className="text-sm font-medium">
                Morning Dose
              </Label>
              <Input
                id="morning-time"
                type="time"
                value={morningTime}
                onChange={(e) => setMorningTime(e.target.value)}
                className="bg-secondary/50 border-border focus:ring-primary"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="evening-time" className="text-sm font-medium">
                Evening Dose
              </Label>
              <Input
                id="evening-time"
                type="time"
                value={eveningTime}
                onChange={(e) => setEveningTime(e.target.value)}
                className="bg-secondary/50 border-border focus:ring-primary"
              />
            </div>
          </div>
          
          <Button
            onClick={saveSchedule}
            disabled={saving}
            variant="medical"
            className="w-full md:w-auto"
          >
            {saving ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" />
                Save Schedule
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      <Card className="gradient-card border-border/50">
        <CardHeader>
          <CardTitle className="text-lg">Current Schedule Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
              <div className="text-sm text-muted-foreground">Morning Dose</div>
              <div className="text-2xl font-bold text-primary">{morningTime}</div>
            </div>
            <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
              <div className="text-sm text-muted-foreground">Evening Dose</div>
              <div className="text-2xl font-bold text-primary">{eveningTime}</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};