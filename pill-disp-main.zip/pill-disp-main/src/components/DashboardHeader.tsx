import { Pill } from "lucide-react";

export const DashboardHeader = () => {
  return (
    <header className="border-b border-border bg-card/50 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-4 md:py-6">
        <div className="flex items-center gap-2 md:gap-3">
          <div className="gradient-primary p-2 md:p-3 rounded-xl glow-primary">
            <Pill className="h-6 w-6 md:h-8 md:w-8 text-primary-foreground pill-bounce" />
          </div>
          <div>
            <h1 className="text-xl md:text-3xl font-bold gradient-primary bg-clip-text text-transparent">
              Smart Pill Dispenser
            </h1>
            <p className="text-sm md:text-base text-muted-foreground">Medication Management Dashboard</p>
          </div>
        </div>
      </div>
    </header>
  );
};