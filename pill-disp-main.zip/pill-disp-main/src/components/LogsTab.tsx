import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FileText, RefreshCw, Search, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

// Google Sheets CSV endpoint for logs
const LOGS_CSV_URL = "https://docs.google.com/spreadsheets/d/1ebUtFCOwHTaT-ISr-0agxJFY9HGVhP9n9ieNqwP_Uao/export?format=csv";

// Global state to share logs with AnalyticsTab
let globalLogs: LogEntry[] = [];
let logsUpdateCallbacks: (() => void)[] = [];

export const subscribeToLogsUpdates = (callback: () => void) => {
  logsUpdateCallbacks.push(callback);
  return () => {
    logsUpdateCallbacks = logsUpdateCallbacks.filter(cb => cb !== callback);
  };
};

export const getGlobalLogs = () => globalLogs;

interface LogEntry {
  date: string;
  time: string;
  status: "Taken" | "Missed" | "RefillNeeded" | "EMERGENCY ALERT";
  method: string;
}

const getStatusBadge = (status: LogEntry['status']) => {
  switch (status) {
    case "Taken":
      return <Badge className="status-taken">✅ Taken</Badge>;
    case "Missed":
      return <Badge className="status-missed">❌ Missed</Badge>;
    case "RefillNeeded":
      return <Badge className="status-refill">⚠️ Refill Needed</Badge>;
    case "EMERGENCY ALERT":
      return <Badge className="status-emergency">🚨 Emergency</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

export const LogsTab = () => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const { toast } = useToast();
  const refreshIntervalRef = useRef<NodeJS.Timeout>();

  const logsPerPage = 10;

  useEffect(() => {
    loadLogs();
    
    // Auto-refresh every 30 minutes
    refreshIntervalRef.current = setInterval(() => {
      loadLogs();
    }, 30 * 60 * 1000);

    return () => {
      if (refreshIntervalRef.current) {
        clearInterval(refreshIntervalRef.current);
      }
    };
  }, []);

  const parseCSV = (csvText: string): LogEntry[] => {
    const lines = csvText.trim().split('\n');
    const headers = lines[0].split(',').map(h => h.trim());
    
    return lines.slice(1).map(line => {
      const values = line.split(',').map(v => v.trim());
      const entry: any = {};
      
      headers.forEach((header, index) => {
        entry[header.toLowerCase()] = values[index] || '';
      });
      
      return {
        date: entry.date || '',
        time: entry.time || '',
        status: entry.status as LogEntry['status'] || 'Taken',
        method: entry.method || 'Automatic'
      };
    });
  };

  const loadLogs = async () => {
    setLoading(true);
    try {
      const response = await fetch(LOGS_CSV_URL);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const csvText = await response.text();
      const parsedLogs = parseCSV(csvText);
      
      // Sort by date and time (newest first)
      const sortedLogs = parsedLogs.sort((a, b) => {
        const dateA = new Date(`${a.date} ${a.time}`);
        const dateB = new Date(`${b.date} ${b.time}`);
        return dateB.getTime() - dateA.getTime();
      });
      
      setLogs(sortedLogs);
      globalLogs = sortedLogs;
      
      // Notify subscribers (AnalyticsTab)
      logsUpdateCallbacks.forEach(callback => callback());
      
    } catch (error) {
      console.error("Failed to load logs:", error);
      toast({
        title: "Connection Error",
        description: "Failed to load medication logs from Google Sheets. Please check the connection.",
        variant: "destructive",
      });
      
      // Use mock data as fallback
      const mockLogs: LogEntry[] = [
        { date: "2024-01-15", time: "08:00", status: "Taken", method: "Automatic" },
        { date: "2024-01-15", time: "20:00", status: "Taken", method: "Manual" },
        { date: "2024-01-14", time: "08:00", status: "Taken", method: "Automatic" },
        { date: "2024-01-14", time: "20:00", status: "Missed", method: "Automatic" },
        { date: "2024-01-13", time: "08:00", status: "Taken", method: "Automatic" },
        { date: "2024-01-13", time: "20:00", status: "Taken", method: "Automatic" },
      ];
      setLogs(mockLogs);
      globalLogs = mockLogs;
      logsUpdateCallbacks.forEach(callback => callback());
    } finally {
      setLoading(false);
    }
  };

  const filteredLogs = logs.filter(log =>
    log.date.includes(searchTerm) ||
    log.status.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.method.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalPages = Math.ceil(filteredLogs.length / logsPerPage);
  const startIndex = (currentPage - 1) * logsPerPage;
  const paginatedLogs = filteredLogs.slice(startIndex, startIndex + logsPerPage);

  return (
    <div className="space-y-6 fade-in">
      <Card className="gradient-card border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Medication Logs
          </CardTitle>
          <CardDescription>
            Track your medication intake history and compliance status.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search logs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 bg-secondary/50 border-border"
              />
            </div>
            <Button
              onClick={loadLogs}
              disabled={loading}
              variant="outline"
              className="shrink-0"
            >
              {loading ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-2" />
              )}
              Refresh
            </Button>
          </div>

          <div className="rounded-lg border border-border/50 overflow-hidden overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-secondary/30">
                  <TableHead className="whitespace-nowrap">Date</TableHead>
                  <TableHead className="whitespace-nowrap">Time</TableHead>
                  <TableHead className="whitespace-nowrap">Status</TableHead>
                  <TableHead className="whitespace-nowrap">Method</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8">
                      <div className="flex items-center justify-center gap-2 text-muted-foreground">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Loading logs...
                      </div>
                    </TableCell>
                  </TableRow>
                ) : paginatedLogs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                      No logs found
                    </TableCell>
                  </TableRow>
                ) : (
                  paginatedLogs.map((log, index) => (
                    <TableRow
                      key={`${log.date}-${log.time}-${index}`}
                      className="hover:bg-secondary/20 transition-smooth"
                    >
                      <TableCell className="font-medium whitespace-nowrap">{log.date}</TableCell>
                      <TableCell className="whitespace-nowrap">{log.time}</TableCell>
                      <TableCell className="whitespace-nowrap">{getStatusBadge(log.status)}</TableCell>
                      <TableCell className="text-muted-foreground whitespace-nowrap">{log.method}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 && (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mt-4">
              <div className="text-xs sm:text-sm text-muted-foreground text-center sm:text-left">
                Showing {startIndex + 1} to {Math.min(startIndex + logsPerPage, filteredLogs.length)} of {filteredLogs.length} entries
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(currentPage - 1)}
                >
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage(currentPage + 1)}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};