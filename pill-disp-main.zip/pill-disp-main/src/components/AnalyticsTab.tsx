import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, TrendingUp, Calendar, Activity } from "lucide-react";
import { getGlobalLogs, subscribeToLogsUpdates } from "./LogsTab";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

interface AnalyticsData {
  complianceRate: number;
  totalDoses: number;
  takenDoses: number;
  missedDoses: number;
  weeklyData: { day: string; taken: number; missed: number }[];
}

const calculateAnalytics = (logs: any[]): AnalyticsData => {
  if (logs.length === 0) {
    return {
      complianceRate: 0,
      totalDoses: 0,
      takenDoses: 0,
      missedDoses: 0,
      weeklyData: []
    };
  }

  const takenDoses = logs.filter(log => log.status === "Taken").length;
  const missedDoses = logs.filter(log => log.status === "Missed").length;
  const totalDoses = takenDoses + missedDoses;
  const complianceRate = totalDoses > 0 ? Math.round((takenDoses / totalDoses) * 100 * 10) / 10 : 0;

  // Get last 7 days of data
  const today = new Date();
  const weeklyData = [];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  for (let i = 6; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(today.getDate() - i);
    const dateString = date.toISOString().split('T')[0];
    
    const dayLogs = logs.filter(log => log.date === dateString);
    const dayTaken = dayLogs.filter(log => log.status === "Taken").length;
    const dayMissed = dayLogs.filter(log => log.status === "Missed").length;
    
    weeklyData.push({
      day: dayNames[date.getDay()],
      taken: dayTaken,
      missed: dayMissed
    });
  }

  return {
    complianceRate,
    totalDoses,
    takenDoses,
    missedDoses,
    weeklyData
  };
};

export const AnalyticsTab = () => {
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);

  const updateAnalytics = () => {
    const logs = getGlobalLogs();
    const analytics = calculateAnalytics(logs);
    setAnalyticsData(analytics);
    setLoading(false);
  };

  useEffect(() => {
    // Initial load
    updateAnalytics();
    
    // Subscribe to log updates
    const unsubscribe = subscribeToLogsUpdates(updateAnalytics);
    
    return unsubscribe;
  }, []);

  if (loading || !analyticsData) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">Loading analytics...</div>
      </div>
    );
  }

  const complianceChartData = {
    labels: ['Taken', 'Missed'],
    datasets: [
      {
        data: [analyticsData.takenDoses, analyticsData.missedDoses],
        backgroundColor: ['hsl(var(--success))', 'hsl(var(--destructive))'],
        borderColor: ['hsl(var(--success))', 'hsl(var(--destructive))'],
        borderWidth: 2,
      },
    ],
  };

  const weeklyChartData = {
    labels: analyticsData.weeklyData.map(d => d.day),
    datasets: [
      {
        label: 'Taken',
        data: analyticsData.weeklyData.map(d => d.taken),
        backgroundColor: 'hsl(var(--success) / 0.8)',
        borderColor: 'hsl(var(--success))',
        borderWidth: 1,
      },
      {
        label: 'Missed',
        data: analyticsData.weeklyData.map(d => d.missed),
        backgroundColor: 'hsl(var(--destructive) / 0.8)',
        borderColor: 'hsl(var(--destructive))',
        borderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          color: 'hsl(var(--foreground))',
          font: {
            family: 'Poppins',
          },
        },
      },
      tooltip: {
        backgroundColor: 'hsl(var(--card))',
        titleColor: 'hsl(var(--foreground))',
        bodyColor: 'hsl(var(--foreground))',
        borderColor: 'hsl(var(--border))',
        borderWidth: 1,
      },
    },
    scales: {
      x: {
        ticks: {
          color: 'hsl(var(--muted-foreground))',
          font: {
            family: 'Poppins',
          },
        },
        grid: {
          color: 'hsl(var(--border))',
        },
      },
      y: {
        ticks: {
          color: 'hsl(var(--muted-foreground))',
          font: {
            family: 'Poppins',
          },
        },
        grid: {
          color: 'hsl(var(--border))',
        },
      },
    },
  };

  const doughnutOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          color: 'hsl(var(--foreground))',
          font: {
            family: 'Poppins',
          },
        },
      },
      tooltip: {
        backgroundColor: 'hsl(var(--card))',
        titleColor: 'hsl(var(--foreground))',
        bodyColor: 'hsl(var(--foreground))',
        borderColor: 'hsl(var(--border))',
        borderWidth: 1,
      },
    },
  };

  return (
    <div className="space-y-6 fade-in">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="gradient-card border-border/50">
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-success" />
              <div>
                <p className="text-sm text-muted-foreground">Compliance Rate</p>
                <p className="text-2xl font-bold text-success">
                  {analyticsData.complianceRate}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="gradient-card border-border/50">
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Total Doses</p>
                <p className="text-2xl font-bold">
                  {analyticsData.totalDoses}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="gradient-card border-border/50">
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-success" />
              <div>
                <p className="text-sm text-muted-foreground">Doses Taken</p>
                <p className="text-2xl font-bold text-success">
                  {analyticsData.takenDoses}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="gradient-card border-border/50">
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-destructive" />
              <div>
                <p className="text-sm text-muted-foreground">Doses Missed</p>
                <p className="text-2xl font-bold text-destructive">
                  {analyticsData.missedDoses}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="gradient-card border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-primary" />
              Weekly Compliance
            </CardTitle>
            <CardDescription>
              Daily medication intake over the past week
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-48 md:h-64">
              <Bar data={weeklyChartData} options={chartOptions} />
            </div>
          </CardContent>
        </Card>

        <Card className="gradient-card border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5 text-primary" />
              Overall Compliance
            </CardTitle>
            <CardDescription>
              Total doses taken vs missed this week
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-48 md:h-64 flex items-center justify-center">
              <div className="w-32 h-32 md:w-48 md:h-48">
                <Doughnut data={complianceChartData} options={doughnutOptions} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Insights Card */}
      <Card className="gradient-card border-border/50">
        <CardHeader>
          <CardTitle>Insights & Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {analyticsData.complianceRate >= 90 ? (
              <div className="p-4 rounded-lg bg-success/10 border border-success/20">
                <h4 className="font-semibold text-success mb-2">Excellent Compliance! 🎉</h4>
                <p className="text-sm text-muted-foreground">
                  You're maintaining excellent medication adherence. Keep up the great work!
                </p>
              </div>
            ) : analyticsData.complianceRate >= 70 ? (
              <div className="p-4 rounded-lg bg-warning/10 border border-warning/20">
                <h4 className="font-semibold text-warning mb-2">Good Progress ⚠️</h4>
                <p className="text-sm text-muted-foreground">
                  Your compliance is good, but there's room for improvement. Consider setting reminders for missed doses.
                </p>
              </div>
            ) : (
              <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/20">
                <h4 className="font-semibold text-destructive mb-2">Needs Attention 🚨</h4>
                <p className="text-sm text-muted-foreground">
                  Your compliance rate could be better. Please consult with your healthcare provider and consider adjusting your routine.
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};