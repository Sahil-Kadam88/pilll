import { useState } from "react";
import { cn } from "@/lib/utils";
import { Calendar, FileText, BarChart3 } from "lucide-react";

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const tabs = [
  { id: 'schedule', label: 'Schedule', icon: Calendar },
  { id: 'logs', label: 'Logs', icon: FileText },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
];

export const Navigation = ({ activeTab, onTabChange }: NavigationProps) => {
  return (
    <nav className="border-b border-border bg-card/30 backdrop-blur-sm overflow-x-auto">
      <div className="container mx-auto px-4">
        <div className="flex space-x-4 md:space-x-8 min-w-max">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={cn(
                  "flex items-center gap-1 md:gap-2 px-3 md:px-4 py-3 md:py-4 text-xs md:text-sm font-medium transition-smooth relative shrink-0",
                  "hover:text-primary hover:bg-primary/5 rounded-t-lg",
                  activeTab === tab.id
                    ? "text-primary bg-primary/10 border-b-2 border-primary"
                    : "text-muted-foreground"
                )}
              >
                <Icon className="h-4 w-4" />
                <span className="hidden sm:inline">{tab.label}</span>
                <span className="sm:hidden">{tab.label.slice(0, 3)}</span>
                {activeTab === tab.id && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 gradient-primary" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};